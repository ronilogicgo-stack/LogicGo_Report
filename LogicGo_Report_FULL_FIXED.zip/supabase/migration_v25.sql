-- =====================================================================
-- v25: Missed daily-entry notifications + Holiday / Leave / Custom /
-- Requested tagging on daily_entries.
--
-- HOW TO RUN: Supabase Dashboard -> SQL Editor -> paste this whole file
-- -> Run. Safe to run once. It only adds new things; it does not touch
-- any existing data.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Tag every daily_entries row with WHY it exists.
--    'submitted' = the sales person (or admin on their behalf) actually
--                  entered real numbers for that day - counts normally.
--    'holiday'   = auto (Friday) or Admin-marked holiday - excluded from
--                  "days reported" and shown as a note, not a number.
--    'leave'     = Admin marked this day as the person's leave.
--    'custom'    = Admin marked this day with a custom comment/tag.
--    'requested' = Admin asked the sales person to fill this day in; an
--                  empty row exists so it shows up as "to do" on their
--                  dashboard. Becomes 'submitted' the moment they save
--                  real numbers into it (handled by the app, not SQL).
-- ---------------------------------------------------------------------
alter table public.daily_entries
  add column if not exists entry_type text not null default 'submitted';

alter table public.daily_entries
  drop constraint if exists daily_entries_entry_type_check;

alter table public.daily_entries
  add constraint daily_entries_entry_type_check
  check (entry_type in ('submitted', 'holiday', 'leave', 'custom', 'requested'));

-- Every row that already exists is real reported data.
update public.daily_entries set entry_type = 'submitted' where entry_type is null;

create index if not exists idx_daily_entries_entry_type
  on public.daily_entries (entry_type);

-- The "days reported" total should only count real submitted entries,
-- not Friday/holiday/leave/custom/requested placeholder rows.
create or replace view public.monthly_entry_totals
with (security_invoker = true) as
select
  user_id,
  date_trunc('month', entry_date)::date as month,
  sum(sales) as total_sales,
  sum(collections) as total_collections,
  sum(sales_return) as total_sales_return,
  sum(net_sales) as total_net_sales,
  count(*) filter (where entry_type = 'submitted') as days_reported,
  sum(other_transaction) as total_other_transaction
from public.daily_entries
group by user_id, date_trunc('month', entry_date);

-- ---------------------------------------------------------------------
-- 2) Reusable custom holiday reasons, so an Admin doesn't have to
--    retype "Eid Vacation" (etc.) every single time - pick it from a
--    dropdown after the first time it's used.
-- ---------------------------------------------------------------------
create table if not exists public.holiday_reasons (
  id uuid primary key default gen_random_uuid(),
  label text not null unique,
  created_at timestamptz default now()
);

alter table public.holiday_reasons enable row level security;

drop policy if exists "holiday_reasons: admin can read" on public.holiday_reasons;
create policy "holiday_reasons: admin can read"
  on public.holiday_reasons for select
  using (public.is_admin());

drop policy if exists "holiday_reasons: admin can insert" on public.holiday_reasons;
create policy "holiday_reasons: admin can insert"
  on public.holiday_reasons for insert
  with check (public.is_admin());

-- ---------------------------------------------------------------------
-- 3) Missed-entry notifications for Admins. One row per (person, date)
--    that was checked and found missing - the nightly cron job (see
--    /api/cron/check-missed-entries) creates these; Admins resolve them
--    from /admin/notifications.
-- ---------------------------------------------------------------------
create table if not exists public.admin_notifications (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'missed_entry',
  user_id uuid not null references public.profiles(id) on delete cascade,
  entry_date date not null,
  message text not null,
  resolved boolean not null default false,
  resolved_action text, -- 'holiday' | 'leave' | 'custom' | 'requested'
  resolved_at timestamptz,
  resolved_by uuid references public.profiles(id),
  created_at timestamptz default now(),
  unique (user_id, entry_date, type)
);

create index if not exists idx_admin_notifications_unresolved
  on public.admin_notifications (resolved, created_at);

alter table public.admin_notifications enable row level security;

drop policy if exists "admin_notifications: admin can read" on public.admin_notifications;
create policy "admin_notifications: admin can read"
  on public.admin_notifications for select
  using (public.is_admin());

drop policy if exists "admin_notifications: admin can update" on public.admin_notifications;
create policy "admin_notifications: admin can update"
  on public.admin_notifications for update
  using (public.is_admin());

-- No insert/delete policy for regular users - only the cron job writes
-- here, and it uses the Service Role key, which bypasses RLS entirely.
